var q = require('q');
var util = require (__dirname + '/../lib/util');

outdir = '.';

var language = 'c++';
var languages = ['c', 'c++', 'c++03', 'c++-msvc11', 'cs', 'goops', 'java', 'java7', 'javascript', 'mcrl2', 'python'];

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['', 'depends[=TYPE]', 'generate dependency for DZN-FILE and write to DZN-FILE.TYPE, default is stdout'],
    ['c', 'calling-context=TYPE', 'generate extra parameter of TYPE for every event'],
    ['g', 'glue=TYPE', 'generate glue for TYPE [dzn]'],
    ['h', 'help', 'display this help and exit'],
    ['I', 'import=DIR+', 'add DIR to import path'],
    ['l', 'language=LANG', 'generate code for language=LANG [' + language + ']'],
    ['m', 'model=MODEL', 'generate main for MODEL'],
    ['o', 'output=DIR', 'write output to DIR (use - for stdout)'],
    ['s', 'shell=MODEL', 'generate thread safe system shell for MODEL'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
  ]);
  option_parser.bindHelp (
code.help + '\n\
\n\
Usage: dzn code [OPTION]... DZN-FILE [MAP-FILE]...\n\
Options:\n\
[[OPTIONS]]\n'
      + 'Languages: ' + languages.join (', '));

  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  args.options.language = args.options.language || language;
  if (args.options.output) {
    outdir = args.options.output;
  }
  if (args.argv.length < 2) {
    option_parser.errorFunc ('error: missing required DZN-FILE');
  }
  return args;
}

var code = {
  help: 'Generate code from a dezyne file',
  exec: function (argv) {return util.exec_n (parse_opts (argv));}
};

module.exports = code;
