var fs = require ('fs');
var q = require ('q');

var util = require (__dirname + '/../lib/util');

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['c', 'components', 'list components'],
    ['h', 'help', 'display this help and exit'],
    ['i', 'interfaces', 'list interfaces'],
    ['I', 'import=DIR+', 'add DIR to import path'],
    ['s', 'systems', 'list systems'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
  ]);
  option_parser.bindHelp (
parse.help + '\n\
\n\
Usage: dzn parse [OPTION]... DZN-FILE...\n\
Options:\n\
[[OPTIONS]]');
  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });
  var args = option_parser.parse (argv);
  args.options.session = session;
  if (args.argv.length < 2) {
    option_parser.errorFunc ('error: missing required DZN-FILE');
  }
  return args;
}

var parse = {
  help: 'Parse a dezyne file and list syntax errors',
  exec: function (argv) {return util.exec_n (parse_opts (argv));}
};
module.exports = parse;

