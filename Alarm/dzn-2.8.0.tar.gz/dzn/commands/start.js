var q = require ('q');
var util = require (__dirname + '/../lib/util');

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['d', 'debug', 'enable debug ouput, do not detach and daemonize'],
    ['h', 'help', 'display this help and exit'],
    ['v', 'verbose+', 'be more verbose'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
    ]);
  option_parser.bindHelp (
start.help + '\n\
\n\
Usage: dzn start\n\
Options:\n\
[[OPTIONS]]');
  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  args.options.verbose = (args.options.verbose && args.options.verbose.length)
    || args.options.verbose;
  if (args.argv.length > 1) {
    option_parser.errorFunc ('error: unknown argument: ' + args.argv[1]);
  }
  return args;
}

var start = {
  help: 'Start daemon',
  start: function (argv) {
    var arguments = parse_opts (argv);
    var d = require ('dzn-daemon/lib/config')['default'];
    d.debug = arguments.options.debug;
    d.verbose = arguments.options.verbose || (verbose==1) && 1 || (verbose>1) && (verbose-1)
    d.home = home;
    d.datadir = __dirname + '/../';
    if (d.debug) {
      require ('dzn-daemon').main (d);
    }
    else {
      util.spawn ([__dirname + '/../bin/daemon'].concat (JSON.stringify (d)));
    }
  },
  exec: function (argv) {start.start (argv); return q({});}
};
module.exports = start;
