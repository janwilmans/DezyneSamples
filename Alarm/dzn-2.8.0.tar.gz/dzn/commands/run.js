var fs = require('fs');
var path = require('path');
var q = require('q');
var util = require (__dirname + '/../lib/util');

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['b', 'back', 'back up to the point before the last event if any'],
    ['c',  'continue', 'DEPRECATED (is the default) continue until user input is needed'],
    ['f', 'forward=EVENT', 'execute EVENT [stdin]'],
    ['h', 'help', 'display this help and exit'],
    ['I', 'import=DIR+', 'add DIR to import path'],
    ['l', 'locations', 'output trace as program locations and state vector'],
    ['m', 'model=name', 'run model with name=NAME'],
    ['s', 'strict', 'require the trace to be complete, i.e. including all events'],
    ['t', 'trace=TRACE', 'read trace from file=TRACE [stdin]'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
  ]);
  option_parser.bindHelp (
    run.help + '\n\
\n\
Usage: dzn run [OPTION]... DZN-FILE\n\
Options:\n\
[[OPTIONS]]');
  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  args.options.session = session;
  if (args.argv.length < 2) {
    option_parser.errorFunc ('error: missing required dzn file');
  }
  if (args.argv.length > 2) {
    option_parser.errorFunc ('error: unknown argument: ' + args.argv[2]);
  }
  return args;
}

var global_reading_p;

function read_stream (stream) {
  var future = q.defer ();
  var s = '';
  stream.on ('data', function (data) {
    global_reading_p = true;
    s += data.toString ();
  });
  stream.on ('error', function (e) {future.resolve (s);});
  stream.on ('end', function () {future.resolve (s);});
  return future.promise;
}

function read_trace_from_stdin () {
  function prompt () {
    if (global_reading_p) return;
    process.stderr.write ('trace> ');
  }
  setTimeout (prompt, 100);
  return read_stream (process.stdin);
}

var run = {
  help: 'Run trace through dezyne model',
  exec: function (argv) {
    var args = parse_opts (argv);
    var dzn = args.argv[1];

    if(args.options.back || args.options.forward)
      return util.exec_1(args);

    return (args.options.trace
            ? q.denodeify (fs.readFile) (args.options.trace, 'ascii')
            : read_trace_from_stdin ())
      .then (function (trace) {
        trace = trace
          .replace (/[, \t\r\n]+/g, '\n');
        if (typeof (args.options.forward) === 'string')
          args.options.forward = trace;
        else
          args.options.trace = trace;
        return util.exec_1 (args)
      })
  }
};

module.exports = run;
