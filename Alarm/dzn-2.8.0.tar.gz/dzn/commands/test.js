var q = require('q');
var util = require (__dirname + '/../lib/util');

function parse_opts(argv) {
  var getopt = require('node-getopt');
  var option_parser = getopt.create
  ([
    ['h', 'help', 'display this help and exit'],
    ['m', 'message=MESSAGE', 'send message MESSAGE'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
    ['w', 'wait=MSEC', 'wait MSEC milliseconds before sending response'],
    ]);
  option_parser.bindHelp(
'Send test, ping server.\n\
\n\
Usage: dzn test [OPTION]...\n\
Options:\n\
[[OPTIONS]]\n'
  );

  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });
  var args = option_parser.parse (argv);
  return args;
}

var exports = {
  exec: function (argv) {
    var args = parse_opts(argv);
    return args.options.message ? q(JSON.parse(args.options.message)) : util.exec_0(args); }
}
module.exports = exports;
