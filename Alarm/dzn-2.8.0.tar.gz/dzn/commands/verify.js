var debug = require (__dirname + '/debug');

var dzn = require (__dirname + '/../index');
var util = require (__dirname + '/../lib/util');

var g_options;
function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['a', 'all', 'run all checks'],
    ['d', 'debug', 'drop into debugger upon failure trail'],
    ['h', 'help', 'display this help and exit'],
    ['I', 'import=DIR+', 'add DIR to import path'],
    ['l', 'locations', 'output trace as program locations and state vector'],
    ['m', 'model=NAME', 'verify model with name=NAME'],
    ['q', 'queue_size=SIZE', 'use queue size=SIZE for verification'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
  ]);
  option_parser.bindHelp (
verify.help + '\n\
\n\
Usage: dzn verify [OPTION]... DZN-FILE\n\
Options:\n\
[[OPTIONS]]');
  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });
  var args = option_parser.parse (argv);
  args.options.session = session;
  args.options.verbose = verbose;
  g_options = args.options;
  if (args.options.debug) args.options.all = undefined;
  if (args.argv.length < 2) {
    option_parser.errorFunc ('error: missing required DZN-FILE');
  }
  if (args.argv.length > 2) {
    option_parser.errorFunc ('error: unknown argument: ' + args.argv[2]);
  }
  return args;
}

var verify = {
  help: 'Verify dezyne model and show trace upon error'
  ,
  fail_re: /(^|\n)verify:[^\n]*: check: [^\n]*: fail/
  ,
  status: 0
  ,
  exec: function (argv) {return util.exec_1 (parse_opts (argv));}
  ,
  is_progress: function (err) {return err.slice(-1) === '\r' || err[0] === '\b' || err[0] === '\r';}
  ,
  progress: function (command) {
    verify.status |= command.status;
    verify.status |= (command.stderr && !verify.is_progress(command.stderr));
    verify.status |= command.stdout && verify.fail_re.test (command.stdout);
    return dzn.progress (command);
  }
  ,
  result: function (verbose) {
    return function (command) {
      verify.status |= command.status;
      verify.status |= (command.stderr && !verify.is_progress(command.stderr));
      verify.status |= command.stdout && verify.fail_re.test (command.stdout);
      command.status |= verify.status;
      if (g_options.debug && command.status)
        return debug.result (verbose) (command);
      return dzn.result (false /*do not print: no errors found*/) (command);
    }
  }
};
module.exports = verify;
