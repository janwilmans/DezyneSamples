var q = require ('q');
var util = require (__dirname + '/../lib/util');

function parse_opts (argv) {
  var signals = ['HUP', 'KILL', 'TERM'];
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['h', 'help', 'display this help and exit'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
    ['s', 'signal=SIGNAL', 'send signal=SIGNAL to daemon [HUP]'],
  ]);
  option_parser.bindHelp (
kill.help + '\n\
\n\
Usage: dzn kill\n\
Options:\n\
[[OPTIONS]]\n\
\n\
Signals: ' + signals + '\n');
  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  if (args.argv.length > 1) {
    option_parser.errorFunc ('error: unknown argument: ' + args.argv[1]);
  }

  args.options.signal
    = args.options.signal
    && signals.indexOf (args.options.signal) == -1
    && option_parser.errorFunc ('error: no such signal: ' + args.options.signal)
    || args.options.signal
    || 'HUP';
  return args;
}

var kill = {
  help: 'Kill daemon',
  exec: function (argv) {return util.exec_0 (parse_opts (argv));},
};
module.exports = kill;
