var fs = require ('fs');
var prompt = require ('prompt');
var q = require ('q');

var dzn = require (__dirname + '/../index.js');
var util = require (__dirname + '/../lib/util');

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['b', 'backtrace', 'display bactrace'],
    ['h', 'help', 'display this help and exit'],
    ['m', 'model=name', 'debug model with name=NAME'],
    ['t', 'trail=FILE', 'run trail from FILE'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
    ]);
  option_parser.bindHelp (
debug.help + '\n\
\n\
Usage: dzn debug\n\
Options:\n\
[[OPTIONS]]');
  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  args.options.session = session;
  args.options.cwd = process.cwd ();
  if (args.options.trail)
    args.options.trail = fs.readFileSync (args.options.trail).toString ()
    .replace (/ /g, '\n')
    .replace (/,/g, '\n')
    .split ('\n');
  if (args.argv.length > 2) {
    option_parser.errorFunc ('error: unknown argument: ' + args.argv[1]);
  }
  return args;
}

var g_future;
var g_startup = true;
var g_backtrace;
var g_model;
var g_eligible = [];
var g_trace = [];
var g_files;
var g_last_command = 'help';
var g_trail;
var g_skip = 0;

function get_command (command) {
  command = command || {};
  command.options = command.options || {};
  //command.cwd = command.options.cwd;

  g_debug && console.log ('get_command command=' + util.str (command))
  if (command.files && command.files.length && !g_files) {
    if (command.options && command.options.trail)
      g_trail = command.options.trail;
    g_files = command.files;
    return q ({name:'file',model:command.options.model,cwd:command.options.cwd,options:[command.files[0].name]});
  }
  if (g_files && g_trail) {
    command.files = [];
    command = {name:'trail',options:g_trail};
    g_trail = undefined;
    return q (command);
  }
  if (g_backtrace || command.options.backtrace) {
    g_backtrace = command.options.backtrace = false;
    g_files = [];
    return q ({name:'fr',options:[]});
  }
  if (g_startup) {
    g_startup = false;
    console.log ('For help, type "help".');
  }

  //command.options.cwd = process.cwd ();
  g_model = command.options.model || g_model;
  var model = g_model;
  prompt.start ();
  prompt.colors = false;
  prompt.message = 'dzn';
  prompt.description = (model && '(' + model + ')') || '';
  prompt.delimiter = '';
  return q.denodeify (prompt.get) ({name:'dzn',message:prompt.description + '> '})
    .then (function (result) {
      var line = result.dzn || g_last_command;
      g_last_command = line;
      var argv = line.split (/ +/);
      var cmd = argv[0];
      g_debug && console.error ('line: ' + util.str (line))
      if (cmd && cmd === 'debug') {
        g_debug = !g_debug;
        cmd = undefined;
      }
      if (!cmd) return get_command (command);
      command = {name:cmd,options:argv.slice (1)};
      if (cmd && cmd === 'file'.slice (0, cmd.length)) {
        if (!command.options.length) {
          console.log ('missing FILE');
          return get_command (command);
        }
        command.name == 'file';
        return util.exec_1 ({argv:argv,options:command.options})
          .then (function (args) {
            command.files = args.files;
            //command.options.command.options = []; // TODO: model option
            return command;
          })
          .fail (function (e) {
            console.error ('' + e);
            return get_command (command);
          })
      }
      if (cmd && cmd === 'trail'.slice (0, cmd.length)) {
        return util.exec_1 ({argv:argv,options:command.options})
          .then (function (args) {
            command.files = [];
            var trail = args.files[0].content.split ('\n');
            command.options = trail;
            return command;
          })
          .fail (function (e) {
            console.error ('' + e);
            return get_command (command);
          })
      }
      if (cmd && cmd === 'quit'.slice (0, cmd.length)) {
        console.log ('bye');
        process.exit (0);
      }
      g_debug && console.log ('get_command => ' + util.str (command))
      return command;
    })
}

function parse (msg) {
  var command = msg.command;
  //g_debug && console.error ('command: ' + util.str (command));
  command = command || {};
  command.stdout && console.log (command.stdout.trim ());
  command.stderr && console.error (command.stderr.trim ());
  var model = command.stdout
      && command.stdout.match (/(^|\n)model:([^\n]*)/);
  g_model = model && model[2] || g_model;
  var eligible = command.stdout
      && command.stdout.match (/(^|\n)eligible:([^\n]*)/);
  g_eligible = eligible && eligible[2] && eligible[2].split (',') || g_eligible;
  var trace = command.stdout
      && command.stdout.match (/(^|\n)trace:([^\n]*)/);
  g_trace = trace && trace[2] && trace[2].split (',') || g_trace;
}

function repl (msg) {
  g_debug && console.log ('REPL msg=' +util.str (msg))
  var url = g_config.daemon;
  var ws = new require ('ws') (url.replace (/^http[^:]*:/, 'ws:'));

  ws.on ('open', function (xmsg) {
    ws.on ('message', function (data) {
      g_debug && console.log ('RECV=' + data);
      var msg = JSON.parse (data);
      msg = msg.debug && msg.debug || msg;
      if (msg.post || msg.type || msg.selection) return;
      var post_p = msg.post || msg.type;
      msg = msg.post && msg.post || msg;
      parse (msg);

      get_command ({options:{}})
        .then (function (command) {
          //command = {command:{name:'help'}};
          g_debug && console.log ('SEND=' + JSON.stringify ({command:command}));
          ws.send (JSON.stringify ({debug:{command:command}}));
        })
        .done ();
    });
    ws.send (JSON.stringify ({register:{session:session,type:'debugger'}}));

    get_command (msg)
      .then (function (command) {
        command = command || {name:'help',debug:true};
        g_debug && console.log ('SEND=' + JSON.stringify ({command:command}));
        ws.send (JSON.stringify ({debug:{command:command}}));
      })
      .done ();
  });
}
  
var debug = {
  help: 'Run debugger'
  ,
  exec: function (argv) {
    var args = parse_opts (argv);
    if (args.argv.length > 1)
      util.exec_1 (args)
      .then (repl);
    else
      repl ({name:'debug',options:args.options,files:[]});
    g_future = q.defer ();
    return g_future.promise;
  }
};

module.exports = debug;
