var q = require('q');
var util = require(__dirname + '/../lib/util');

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['h', 'help', 'display this help and exit'],
    ['R', 'recursive', 'list subdirectories recursively'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
  ]);
  option_parser.bindHelp (
ls.help + '\n\
\n\
Usage: dzn ls [OPTION]... [FILE]...\n\
Options:\n\
[[OPTIONS]]');

  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  args.options.files = args.argv.splice (1);
  return args;
}

var ls = {
  help: 'List information about files in cloud',
  exec: function (argv) {return util.exec_0(parse_opts (argv));}
};
module.exports = ls;
