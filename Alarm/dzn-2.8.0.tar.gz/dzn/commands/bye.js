var util = require (__dirname + '/../lib/util');

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['h', 'help', 'display this help and exit'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
    ]);
  option_parser.bindHelp (
bye.help + '\n\
\n\
Usage: dzn bye\n\
Options:\n\
[[OPTIONS]]');
  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  if (args.argv.length > 1) {
    option_parser.errorFunc ('error: unknown argument: ' + args.argv[1]);
  }
  return args;
}

var bye = {
  help: 'Send bye to server, close session',
  exec: function (argv) {return util.exec_0 (parse_opts (argv));}
};
module.exports = bye;
