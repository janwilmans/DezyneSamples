
var fs = require ('fs');
var path = require ('path');
var q = require ('q');
var request = require ('request');

var version = require (__dirname + '/lib/version');
var transports = require(__dirname + '/lib/transports');
var util = require (__dirname + '/lib/util');

var daemon_url = 'http://localhost:4000';

var lockfile = require('lockfile');

g_config = {url:'https://hosting.verum.com', daemon:daemon_url, user:process.env['GIT_AUTHOR_EMAIL']};
g_config_file = process.env['DZN_CONFIG'] || (home + '/.dzn.json');
g_config_lock = g_config_file + '.lock';

g_debug = false;
html = false;
json = false;
session = false;
verbose = false;
installing = false;

var dzn_prefix_options = ['-s','-u','-r'];
function parse_opts (commands) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['d', 'debug', 'enable debug ouput'],
    ['h', 'help', 'display this help and exit'],
    ['H', 'html', 'output html'],
    ['j', 'json', 'output json'],
    ['p', 'prompt', 'prompt for password'],
    ['s', 'server=URL', 'connect to server URL [' + g_config.url + ']'],
    ['S', 'session=SESSION', 'use session=SESSION [' + util.get_session () + ']'],
    ['u', 'user=USER', 'authenticate as user USER [' + g_config.user + ']'],
    ['v', 'verbose+', 'be more verbose, show progress'],
    ['V', 'version', 'show version and exit'],
  ]);
  var command_help = commands.map (function (s) {
    var m = require (__dirname + '/commands/' + s);
    return (s + '            ').slice (0, 12) + (m.help ? m.help : '');
  });
  option_parser.setHelp (
    'Dezyne command line client.\n\
\n\
Usage: dzn [DZN-OPTION]... COMMAND [COMMAND-ARGUMENT]...\n\
Dzn Options:\n\
[[OPTIONS]]\n\
\n\
Commands:\n  '
      + command_help.join ('\n  ')
      + '\n\n\
Use "dzn COMMAND --help" for command-specific information.\n\
\n\
ENVIRONMENT:\n\n\
  http_proxy=http://[user[:password]@]proxy[:port]\n\
\n\
  Note that characters not allowed in URLs have to be encoded,\n\
  see: https://www.w3.org/Addressing/URL/4_URI_Recommentations.html\n\
\n\
');

  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var argv = [];
  var i = 2;
  for (; i < process.argv.length; i++) {
    if (dzn_prefix_options.indexOf (process.argv[i]) !== -1) {
      i++;
      if (i >= process.argv.length
          || /^-/.test (process.argv[i])) {
        option_parser.errorFunc ();
        process.exit (2);
      }
    }
    else if (/^[^-]/.test (process.argv[i])) {
      break;
    }
  }
  var dzn_argv = process.argv.slice (0, i+1);
  var command_argv = process.argv.slice (i);
  var args = option_parser.parse (dzn_argv.slice (2));

  g_debug = args.options.debug;
  html = args.options.html;
  json = args.options.json || args.options.html;
  session = args.options.session || util.get_session ();
  verbose = (args.options.verbose && args.options.verbose.length)
    || args.options.verbose;

  if(args.options['version']) {
    console.log ('dzn ' + version.version);
    console.log ('Copyright (C) 2017 verum.com');
    process.exit (0);
  }
  if(args.options.prompt) {
    g_config.ticket = null;
  }

  if (args.options.user) {
    if (g_config.user && g_config.user != args.options.user) {
      g_config.ticket = null;
    }
    g_config.user = args.options.user;
  }
  if (args.options.server) {
    g_config.url = args.options.server.replace (/[\/]*$/,'');
  }

  if (!commands.length) {
    args.command = 'hello'
    return {dzn: args, cmd: []};
  }

  if (args.options.help) { // handle --help only after reading commands
    option_parser.showHelp ();
    process.exit (0);
  }

  var command = args.argv[0];
  if (command === undefined) {
    option_parser.errorFunc ();
    process.exit (2);
  }
  if (command && commands.indexOf (command) === -1) {
    option_parser.errorFunc ('error: no such command: ' + command + '\n');
  }

  args.options.session = args.options.session || util.get_session ();
  args.command = command;

  return {dzn: args, cmd: command_argv};
}

var commands_base = ['hello', 'ls', 'start'];
var commands_all = commands_base
    .concat (['bye', 'cat', 'code', 'convert', 'depends', 'kill', 'parse', 'query', 'run', 'table', 'verify', 'system']);

function list_commands () {
  return q.denodeify (fs.readdir) (__dirname + '/commands')
    .then (function (r) {
      var commands = (r && r.filter (function (f) {return path.extname (f) === '.js';}) || [])
          .map (function (f) { return path.basename (f, '.js'); });
      if (!commands.length || commands.length < commands_all.length) {
        throw 'fail';
      }
      return commands;
    })
    .fail (function (err) {
      if (g_debug) {
        console.error (util.str (err));
      }
      return update_commands ()
        .then (list_commands)
        .fail (function (err) { console.error (err); return []; });
    });
}

function get_command () {
  return list_commands ()
    .then (function (commands) {
      return parse_opts (commands);
    });
}

function log_helper (m, o) {g_debug && console.error (m + util.str (o));};
log = {
  info: log_helper,
  debug: log_helper,
  trace: util.identity,
  warn: log_helper,
};

var dzn = {
  call_daemon: function (script, args, prompt) {
    var options;
    var url = g_config.daemon;
    var future = q.defer();
    var orig_msg;
    var transport = new transports.ws (url);
    var api = new transports.api (transport, function (future){
      return {
        close: function (transport, msg) {
          if(!installing) process.exit (1);
        }
        ,
        error: function (transport, msg, e) {
          if (msg && msg.command && msg.command.name === 'kill') process.exit (0);
          g_debug || (e = '');
          var s =  'cannot connect to: ' + g_config.url + ' [via ' + url + ']';
          g_debug && console.error (s);
        }
        ,
        read: function (transport, msg) {
          g_debug && console.error ('read:' + util.str (msg));
          try {
            if(util.is_directory(msg.name)) {
              return transport.send ('read', {key: msg.key, name:msg.name,files:fs.readdirSync(msg.name)}).done ();
            } else {
              var file = util.read_file_in_dirs(msg.filename, [msg.parent_path].concat(options.import || []));
              file.key = msg.key;
              return transport.send ('read', file).done ();
            }
          } catch(err) { console.error(err.stack + 'no such file: ' + msg.name); process.exit(1); }
        }
        ,
        post: function (transport, response) {
          g_debug && util.debug ('recv: ', util.str (response));
          if (response.type === 'progress') (script.progress || dzn.progress) (response.command);
          else if (response.type === 'result') future.resolve(response);
          else if (response.type === 'error') future.resolve(response);
          else if (response.type === 'deny') future.resolve(response);
          else if (response.type === 'install') {
            g_debug && console.error ('installing: ' + installing);
            transport.end ('post', {command:{name:'kill'}})
              .finally(function () {
                if (installing) {
                  throw new Error('programming error: already installing...bailing out');
                }
                var install = response.command.files[0].content;
                return dzn.install_daemon (install)
                  .then (function(){
                    dzn.start_daemon (); //race with kill
                    return api.command (orig_msg, future);
                  });
              })
                .fail(function(e){future.reject(e);})
              .done();
          }
          else future.reject(new Error('invalid message type:' + util.str (response)));
        }}});

    g_debug && console.log ('util.daemon: running=' + script.exec);
    args = Array.isArray (args) ? args : [];
    return script.exec (args)
      .then (function (command) {options = command.options; return dzn.create_message (command, prompt);})
      .then (function (msg) {orig_msg=msg;return api.command(msg, future);})
      .then (function (response) {return dzn.handle_auth (response);})
      .then (function (response) {return (script.result || dzn.result) (verbose) (response.command);});
  }
  ,
  create_message: function (command, prompt) {
    command.options = command.options || {};
    command.options.cwd = process.cwd ().replace(/\/*$/,'/');

    var msg = {command:command,auth:{},client:{name:'dzn',version:version.version}, url:g_config.url};
    if (g_debug) {
      msg.debug = g_debug;
    }
    if (g_config.user) {
      msg.auth.user = g_config.user;
    }

    var http_proxy = process.env['http_proxy'];
    if (http_proxy) {
      msg.proxy = http_proxy;
    }

    if (prompt) {
      var read = require ('read');
      return q.denodeify (read) ({prompt:'password: ', silent: true})
        .then (function (password) {
          msg.auth.password = password[0];
          g_config.password = password[0];
          return msg;
        });
    }
    msg.auth.ticket = g_config.ticket;
    return q (msg);
  }
  ,
  fetch_install: function () {
    var url = g_config.url + '/download/npm/details/install.js';
    verbose && console.log('fetching: ' + url);
    return q.denodeify (request) (url)
      .then (function (result) {
        if (result[0].statusCode !== 200)
          throw new Error(result[0].request.uri.host + ' ' + result[0].statusCode + ': ' + result[0].body);
        return result[1];
      })
  }
  ,
  handle_auth: function (msg) {
    try {
      if (msg.auth && msg.auth.ticket && g_config.ticket != msg.auth.ticket) {
        try {
          lockfile.lockSync(g_config_lock, {retries:100});
          fs.writeFileSync(g_config_file + '.tmp', JSON.stringify({ticket:msg.auth.ticket,user:msg.auth.user,url:g_config.url,daemon:g_config.daemon}));
          fs.renameSync(g_config_file + '.tmp', g_config_file);
        } catch (e) {
        } finally {
          lockfile.unlockSync(g_config_lock);
        }
      }
    } catch(e) {
      console.error(e);
    }
    return q(msg);
  }
  ,
  install_daemon: function (script) {
    installing = true;
    var f = __dirname + '/install.js';
    fs.writeFileSync (f, script);
    return require (f)
      .main (g_debug);
  }
  ,
  main: function main () {
    if(fs.existsSync(g_config_file)) {
      function read_config() {
        lockfile.lockSync(g_config_lock,{retries:100});
        return JSON.parse(fs.readFileSync(g_config_file).toString());
      }
      var tmp = null;
      while(!tmp) {
        try {
          tmp = read_config();
        } catch (e) {
          //console.error(e);
        } finally {
          lockfile.unlockSync(g_config_lock);
        }
      }
      g_config = tmp;
    }

    return q()
      .then(function(){
        parse_opts ([]); // allow -u, -s to be set for downloads
        require ('dzn-daemon');
      })
      .fail(function() {
        return dzn.fetch_install ()
          .then (function(script) { return dzn.install_daemon(script); })
          .fail(function(e){ console.log('install failed: ' + (typeof (e) === 'string' ? e.trim():e)); process.exit (1); });
      })
      .then (function () {
        return get_command ();
      })
      .then(function(args) {
        dzn.start_daemon (args.dzn);
        return dzn.process_command (args.dzn, [args.dzn.command].concat (args.cmd.slice (1)));
      })
      .done (function (status) {
        if (!g_daemon) process.exit (status);
      }, function (e) {
        console.error (util.str (g_debug ? e.stack : e));
        process.exit (1);
      });
  }
  ,
  process_command: function (options, argv) {
    var script = require (__dirname + '/commands/' + argv[0]);
    if (options.command === 'start') {return script.exec (argv);}
    return dzn.call_daemon (script, argv, options.options.prompt);
  }
  ,
  progress: function (command) {
    if (!command) return;
    if (command.stderr) {
      if (command.stderr.slice (-1) === '\r')
        ((verbose==1 && command.stderr.length <=2) || (verbose>1)) && process.stderr.write(command.stderr);
      else console.error(command.stderr);
    }
    if (command.stdout) console.log(command.stdout);
  }
  ,
  result: function(verbose) {
    return function(command) {
      return (Array.isArray (command.files)
              ? util.result_files (command) : q())
        .then (function () {
          if (verbose && !command.stderr) command.stderr = command.name + ': no errors found';
          dzn.progress (command);
          return command.status;
        })
    }
  }
  ,
  start_daemon: function (options) {
    if (!options || ['kill', 'start'].indexOf (options.command) === -1) {
      require (__dirname + '/commands/start').start (['start']);
    }
  }
  ,
};

module.exports = dzn;
