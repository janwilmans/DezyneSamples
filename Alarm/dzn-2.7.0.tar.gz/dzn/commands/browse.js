var q = require ('q');
var util = require (__dirname + '/../lib/util');

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['h', 'help', 'display this help and exit'],
    ['v', 'verbose+', 'be more verbose'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
  ]);
  option_parser.bindHelp (
browse.help + '\n\
\n\
Usage: dzn [OPTION]... browse [VIEW|URL]\n\
Options:\n\
[[OPTIONS]]');
  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  args.options.session = session;
  args.options.verbose = (args.options.verbose && args.options.verbose.length)
    || args.options.verbose;
  if (args.argv.length > 2) {
    option_parser.errorFunc ('error: unknown argument: ' + args.argv[2]);
  }
  return args;
}

var browse = {
  help: 'Start browser for Dezyne views'
  ,
  exec: function (argv) {
    var args = parse_opts (argv);
    var url = args.argv.length && args.argv[1] || 'view';
    if (url.indexOf (':') === -1) url = g_config.daemon + '/' + url;
    if (url.indexOf ('?') === -1) url += '?session=' + args.options.session;
    console.log ('browse url=' + url);
    args.options.verbose && console.error ('visting: ' + url);
    util.browse (url);
    return q({});
  }
};
module.exports = browse;
