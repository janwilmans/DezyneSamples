var q = require ('q');

var util = require (__dirname + '/../lib/util');

outdir = '.';

var form = 'state';
var forms = ['event', 'state'];

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['d', 'diagram', 'produce svg diagram output'],
    ['f', 'form=FORM', 'generate table for normal form=FORM [' + form + ']'],
    ['h', 'help', 'display this help and exit'],
    ['I', 'import=DIR+', 'add DIR to import path'],
    ['m', 'model=NAME', 'generate table for model=NAME'],
    ['o', 'output=DIR', 'write output to DIR (use - for stdout)'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
  ]);
  option_parser.bindHelp (
table.help + '\n\
\n\
Usage: dzn table [OPTION]... DZN-FILE\n\
Options:\n\
[[OPTIONS]]\n'
      + 'Forms: ' + forms.join (', '));

  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  args.options.session = session;
  args.options.form = args.options.form || form;
  args.options.html = html;
  args.options.json = json || args.options.diagram;
  json = args.options.json;
  if (forms.indexOf (args.options.form) == -1) {
    option_parser.errorFunc('error: no such form: ' + args.options.form);
  }
  if (args.options.output) {
    outdir = args.options.output;
    delete args.options.output;
  }
  if (args.argv.length < 2) {
    option_parser.errorFunc ('error: missing required DZN-FILE');
  }
  if (args.argv.length > 2) {
    option_parser.errorFunc ('error: unknown argument: ' + args.argv[2]);
  }
  return args;
}

var table = {
  help: 'Generate table form of dezyne model',
  exec: function (argv) {return util.exec_1 (parse_opts (argv));}
};

module.exports = table;
