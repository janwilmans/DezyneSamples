var fs = require ('fs');
var path = require ('path');
var util = require (__dirname + '/../lib/util');

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['h', 'help', 'display this help and exit'],
    ['I', 'import=DIR+', 'add DIR to import path'],
    ['v', 'verbose+', 'be more verbose'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
  ]);
  option_parser.bindHelp (
view.help + '\n\
\n\
Usage: dzn view [OPTION]... {DZN-FILE... | DIRECTORY}\n\
Options:\n\
[[OPTIONS]]');
  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  args.options.session = session;
  args.options.verbose = (args.options.verbose && args.options.verbose.length)
    || args.options.verbose;

  if (args.argv.length < 2) {
    option_parser.errorFunc ('error: missing required DZN-FILE');
  }
  if (args.argv.length > 2) {
    var dir = null;
    args.argv.slice(1).map(function (f) { if (fs.statSync(f).isDirectory()) dir = dir || f; });
    if (dir) {
      option_parser.errorFunc ('error: directory must be only argument: ' + dir);
    }
  }
  if (args.argv.length == 2 && fs.statSync(args.argv[1]).isDirectory()) {
    var dir = args.argv[1];
    args.argv.pop();
    args.argv = args.argv
      .concat (fs.readdirSync(dir)
               .filter(function (f){ return path.extname(f) == '.dzn'; })
               .map(function (f) { return path.join(dir,f); }));
    if (args.argv.length < 2) {
      option_parser.errorFunc ('error: directory does not contain dzn files');
    }
  }
  return args;
}

var view = {
  help: 'Generate views for Dezyne file or project'
  ,
  exec: function (argv) {return util.exec_n (parse_opts (argv));}
};
module.exports = view;
