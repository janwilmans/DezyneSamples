var fs = require ('fs');
var q = require ('q');
var util = require (__dirname + '/../lib/util');

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['h', 'help', 'display this help and exit'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
  ]);
  option_parser.bindHelp (
cat.help + '\n\
\n\
Usage: dzn cat [OPTION]... CLOUD-FILE\n\
Options:\n\
[[OPTIONS]]');

  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  if (args.argv.length < 2) {
    option_parser.errorFunc ('error: missing required CLOUD-FILE');
  }
  if (args.argv.length > 2) {
    option_parser.errorFunc ('error: unknown argument: ' + args.argv[2]);
  }
  args.options.files = args.argv.splice (1);
  return args;
}

var cat = {
  help: 'Cat file in cloud',
  exec: function (argv) {return util.exec_0 (parse_opts (argv));}
}

module.exports = cat;
