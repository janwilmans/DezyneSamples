var fs = require('fs');
var q = require('q');
var path = require('path');
var util = require (__dirname + '/../lib/util');

var dzn = require (__dirname + '/../index');

outdir = '.';

function parse_opts (argv) {
  var getopt = require ('node-getopt');
  var option_parser = getopt.create
  ([
    ['g', 'globals', 'create or extend GlobalTypes.dzn with externals'],
    ['', 'glue', 'generate interfaces in namespace "glue"'],
    ['h', 'help', 'display this help and exit'],
    ['I', 'import=DIR', 'add DIR to include path'],
    ['m', 'map', 'generate map file for stub generation'],
    ['o', 'output=DIR', 'write output to DIR'],
    ['s', 'system', 'include system description'],
    ['V', 'version=VERSION', 'use service version=VERSION'],
  ]);
  option_parser.bindHelp (
convert.help + '\n\
\n\
Usage: dzn convert [OPTION]... {IM-FILE | DM-FILE}\n\
Options:\n\
[[OPTIONS]]');
  option_parser.error (function (msg) {
    msg && console.error (msg);
    console.error (option_parser.getHelp ());
    if (msg) {
      process.exit (2);
    }
  });

  var args = option_parser.parse (argv);
  if (args.options.output) {
    outdir = args.options.output;
    delete args.options.output;
  }
  if (args.argv.length < 2) {
    option_parser.errorFunc ('error: missing required ASD-FILE');
  }
  if (args.argv.length > 2) {
	  var dzn = require (__dirname + '/../index');
  }
  return args;
}

var convert = {
  help: 'Convert an ASD model to dezyne',
  exec: function (argv) {
      var args = parse_opts (argv);
      var file = 'GlobalTypes.dzn';
      if (outdir) file = outdir + '/' + file;
      return (args.options.globals
              ? q.denodeify (fs.readFile) (file, 'ascii')
              : q (''))
        .then (function (globalsfile) {
          args.options.globals = globalsfile;
          return util.exec_1 (args)
        })
        .fail(function(e) {
            args.options.globals = '\n';
            return util.exec_1 (args)
        })
  }
  ,
  result: function(verbose) {
	    return function(command) {
	      var stubsfiles = command.files.filter( function(file) {
            return file.filename == 'stubs.txt';
          });

          if (stubsfiles.length) {
		        var buffer = new Buffer(stubsfiles[0].base64, 'base64');
		        var stubs = buffer.toString('binary');

            command.files = command.files.filter(function (file) {

                var searchedfile = file.filename;
                if (outdir) searchedfile = outdir + '/' + searchedfile;

            	return stubs.indexOf(file.filename) == -1 || !fs.existsSync(searchedfile);
            });

   	        command.files = command.files.filter(function (file) {
    		      return file.filename != 'stubs.txt';
            });

          }

	        return dzn.result (verbose) (command);
	    }
  }
};

module.exports = convert;
